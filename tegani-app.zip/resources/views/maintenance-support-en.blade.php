﻿@extends('layouts.app')

@section('title', 'Technical Support & Maintenance | Software Makers (SMLC)')

@section('description', '24/7 technical support, monitoring, and lifecycle maintenance that keep your platforms secure, available, and high-performing.')

@section('content')
<section class="hero-section" style="padding-top: 120px;">
        <div class="container">
            <div class="row align-items-center min-vh-50">
                <div class="col-lg-12 text-center" data-aos="fade-up">
                    <div class="hero-content">
                        <h1 class="display-4 fw-bold mb-4" style="color: #ffffff; text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">
                            <i class="fas fa-tools me-3"></i>
                            Technical Support & <span style="color: #00d4ff;">Maintenance</span>
                        </h1>
                        <p class="lead mb-4" style="color: #e8f4fd; font-size: 1.15rem;">
                            Keep your platforms available and secure with proactive monitoring, preventive maintenance, and rapid incident response from certified engineers.
                        </p>
                        <div class="d-flex flex-wrap justify-content-center gap-3">
                            <a href="index-en.html#contact" class="btn btn-primary btn-lg btn-interactive"><i class="fas fa-headset me-2"></i>Talk to Support</a>
                            <a href="#services" class="btn btn-outline-light btn-lg btn-interactive"><i class="fas fa-laptop-medical me-2"></i>View Services</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 col-xl-8 mx-auto text-center" data-aos="fade-up">
                    <div class="service-overview">
                        <span class="service-badge">Operations Center</span>
                        <h2 class="section-title">Reliability You <span class="text-primary">Can Count On</span></h2>
                        <p class="section-subtitle">
                            We combine ITIL practices, automated monitoring, and bilingual support desks to keep mission-critical applications running 24/7.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5" id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="service-detail-content" data-aos="fade-up">
                        <div class="service-intro">
                            <h3>What We Cover</h3>
                            <p class="lead">We support applications, infrastructure, databases, and integrations across on-prem and cloud environments using SLAs aligned with your business hours.</p>
                        </div>
                        <div class="maintenance-types">
                            <h3>Service Modules</h3>
                            <div class="row">
                                <div class="col-md-6 mb-4">
                                    <div class="maintenance-card">
                                        <div class="maintenance-icon"><i class="fas fa-heartbeat"></i></div>
                                        <h5>Proactive Monitoring</h5>
                                        <p>24/7 health checks, log analytics, and alerting to catch issues before users notice.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="maintenance-card">
                                        <div class="maintenance-icon"><i class="fas fa-screwdriver-wrench"></i></div>
                                        <h5>Preventive Maintenance</h5>
                                        <p>Patch management, capacity planning, and security hardening on a fixed calendar.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="maintenance-card">
                                        <div class="maintenance-icon"><i class="fas fa-phone-volume"></i></div>
                                        <h5>Service Desk</h5>
                                        <p>Multi-channel support (phone, email, portal, WhatsApp) with bilingual agents and clear escalation paths.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <div class="maintenance-card">
                                        <div class="maintenance-icon"><i class="fas fa-shield-halved"></i></div>
                                        <h5>Incident & Problem</h5>
                                        <p>Root-cause analysis, knowledge-base updates, and constant improvements based on ITIL.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="benefits-section">
                            <h3>Customer Benefits</h3>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <div class="benefit-item">
                                        <i class="fas fa-clock"></i>
                                        <h6>Reduced Downtime</h6>
                                        <p>Defined SLAs (15/30/60 minutes) for acknowledgement, response, and resolution.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="benefit-item">
                                        <i class="fas fa-chart-line"></i>
                                        <h6>Predictable Costs</h6>
                                        <p>Fixed monthly plans covering manpower, tooling, and on-site visits.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="benefit-item">
                                        <i class="fas fa-user-shield"></i>
                                        <h6>Compliance Ready</h6>
                                        <p>Change control, audit trails, and backup policies aligned with NCA and ISO 27001.</p>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="benefit-item">
                                        <i class="fas fa-headset"></i>
                                        <h6>Single Point of Contact</h6>
                                        <p>Dedicated service managers and quarterly reviews for transparency.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="service-sidebar" data-aos="fade-left">
                        <div class="sidebar-card">
                            <h4>Choose Your SLA</h4>
                            <ul class="list-unstyled mb-3">
                                <li>Gold: 24/7 with on-site coverage</li>
                                <li>Silver: Business hours + on-call</li>
                                <li>Bronze: 8x5 remote support</li>
                            </ul>
                            <a href="index-en.html#contact" class="btn btn-primary w-100">Request a Support Plan</a>
                        </div>
                        <div class="sidebar-card">
                            <h4>Complementary Services</h4>
                            <ul class="list-unstyled mb-0">
                                <li><a href="{{ route('system-integration-en') }}">Integration Monitoring</a></li>
                                <li><a href="{{ route('process-automation-en') }}">Automation Runbooks</a></li>
                                <li><a href="{{ route('project-management-en') }}">Release Management</a></li>
                                <li><a href="{{ route('consulting-services-en') }}">IT Governance</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="cta-section">
        <div class="container">
            <div class="cta-card">
                <h3>Need Always-On Support?</h3>
                <p>Share your environment size and we will provide a tailored SLA, tooling stack, and onboarding plan.</p>
                <a href="index-en.html#contact" class="btn btn-light btn-lg me-3">Talk to Operations</a>
                <a href="tel:+966555883492" class="btn btn-outline-light btn-lg">Call +966 55 588 3492</a>
            </div>
        </div>
    </section>
    <a href="https://wa.me/966555883492?text=Hello%20Software%20Makers" class="whatsapp-fab" aria-label="Contact via WhatsApp" target="_blank" rel="noopener">
        <svg viewBox="0 0 32 32" aria-hidden="true" class="whatsapp-icon">
            <path fill="currentColor" d="M26.1 5.9A13.9 13.9 0 1 0 4.7 26.3L3 29.8a1 1 0 0 0 1.3 1.3l3.4-1.7A13.9 13.9 0 1 0 26.1 5.9zM16 28.1c-2.3 0-4.6-.7-6.5-1.9l-.5-.3-3.9 2 2-3.9-.3-.5A12 12 0 1 1 28 16 12 12 0 0 1 16 28.1zm6.6-7.7c-.4-.2-2.3-1.1-2.7-1.3-.4-.1-.7-.2-1 .2-.3.4-1.1 1.3-1.3 1.6-.2.2-.5.3-.9.1-2.3-1.1-4-3-4.6-3.9-.2-.3 0-.6.2-.8.2-.2.4-.5.6-.7.2-.2.3-.4.4-.7.1-.2 0-.5 0-.7 0-.2-1-2.5-1.3-3.4-.3-.8-.7-.7-1-.7h-.9c-.3 0-.7.1-1 .5-.4.4-1.3 1.3-1.3 3.1 0 1.8 1.3 3.6 1.5 3.9.2.3 2.6 3.9 6.3 5.5.9.4 1.6.6 2.1.8.9.3 1.7.2 2.3.1.7-.1 2.3-.9 2.6-1.8.3-.9.3-1.6.2-1.8-.1-.2-.3-.2-.5-.3z"/>
        </svg>
    </a>
    <div id="cookiesBanner" class="cookies-banner">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="cookies-content">
                        <i class="fas fa-cookie-bite me-2"></i>
                        <span>We use cookies to personalise your experience. By continuing to browse, you agree to our <a href="{{ route('terms-en') }}" class="terms-link">Terms & Conditions</a>.</span>
                    </div>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <div class="cookies-actions">
                        <button id="acceptCookies" class="btn btn-primary btn-sm me-2"><i class="fas fa-check me-1"></i>Accept</button>
                        <button id="declineCookies" class="btn btn-outline-light btn-sm"><i class="fas fa-times me-1"></i>Decline</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
